# Chatbot Cristiano Giliberti – Backend Node.js

Chatbot AI per il sito cristianogilibertitecnicoinformatico.it  
Powered by Claude (Anthropic) via Express.js

---

## File del progetto

```
chatbot-cristiano/
├── server.js       ← Backend Express (deploy su Render)
├── widget.html     ← Codice HTML da incollare su Webador
├── package.json
├── .gitignore
└── README.md
```

---

## 🚀 Deploy su Render (backend)

### 1. Carica su GitHub
```bash
git init
git add .
git commit -m "Chatbot Cristiano Giliberti v1"
git remote add origin https://github.com/TUO_USERNAME/chatbot-cristiano.git
git push -u origin main
```

### 2. Crea il Web Service su Render
- Vai su [render.com](https://render.com) → **New → Web Service**
- Connetti il repository GitHub
- Impostazioni:
  - **Name:** chatbot-cristiano
  - **Runtime:** Node
  - **Build Command:** `npm install`
  - **Start Command:** `npm start`

### 3. Aggiungi la variabile d'ambiente
- In Render → **Environment → Add Environment Variable**
  - Key: `ANTHROPIC_API_KEY`
  - Value: `sk-ant-...` (la tua chiave API Anthropic)

### 4. Deploy e copia l'URL
- Render ti darà un URL tipo: `https://chatbot-cristiano.onrender.com`
- Copia questo URL

---

## 🌐 Installazione su Webador

1. Apri il file `widget.html`
2. Alla riga con `const BACKEND_URL = '...'` incolla il tuo URL Render
3. Vai sul pannello Webador → aggiungi blocco **HTML/Codice**
4. Incolla tutto il contenuto di `widget.html`
5. Salva e pubblica

---

## API Endpoint

### `GET /`
Health check – risponde `{ status: "ok" }`

### `POST /chat`
Invia un messaggio al chatbot.

**Body:**
```json
{
  "messages": [
    { "role": "user", "content": "Che servizi offri?" }
  ]
}
```

**Response:**
```json
{
  "reply": "Offro assistenza tecnica, consulenza IT, sicurezza informatica..."
}
```

---

## Sviluppato con Claude by Anthropic
